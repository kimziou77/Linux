#include "Tree.hpp"
#include "TreeNode.hpp"
#include <iostream>
#include <stddef.h>

Tree::Tree() { this->rootnode = NULL; }
Tree::Tree(int data) {
    TreeNode *node = new TreeNode(data);
    this->rootnode = node;
}
Tree::~Tree() {
    delete rootnode->getLeft();
    delete rootnode->getRight();
    delete rootnode;
}
void Tree::insert(int data) {
    TreeNode *node = new TreeNode(data);
    TreeNode *cursor = this->rootnode;
    if (cursor == NULL) {
        this->rootnode = node;
        return;
    }
    while (1) {
        int value = cursor->getData();
        if (value < data) {
            if (cursor->getRight() == NULL) {
                cursor->setRight(node);
                break;
            } else {
                cursor = cursor->getRight();
            }
        } else {
            if (cursor->getLeft() == NULL) {
                cursor->setLeft(node);
                break;
            } else {
                cursor = cursor->getLeft();
            }
        }
    }
    return;
}
void Tree::display() {
    display(this->rootnode, 0);
    return;
}
void Tree::display(TreeNode *curNode, int depth) {
    int i;
    if (curNode == NULL)
        return;
    display(curNode->getRight(), depth + 1);
    for (i = 0; i < depth; i++) {
        std::cout << "   ";
    }
    std::cout << curNode->getData() << std::endl;
    display(curNode->getLeft(), depth + 1);
    return;
}
bool Tree::search(int data) {
    bool result;
    result = search(this->rootnode, data);
    return result;
}
bool Tree::search(TreeNode *curNode, int data) {
    if (curNode == NULL) {
        std::cout << std::endl;
        std::cout << data << " search failed" << std::endl;
        return false;
    }
    if (curNode->getData() == data) {
        std::cout << " " << curNode->getData() << std::endl;
        std::cout << data << " search success!" << std::endl;
        return true;
    }
    if (curNode->getData() > data) {
        std::cout << " " << curNode->getData();
        return search(curNode->getLeft(), data);
    } else {
        std::cout << " " << curNode->getData();
        return search(curNode->getRight(), data);
    }
}
bool Tree::remove(int data) {
    // public의 remove가 호출되면 private의 remove를 호출
    return remove(NULL, this->rootnode, data);
}
bool Tree::remove(TreeNode *preNode, TreeNode *curNode, int data) {
    if (curNode == NULL) {
        std::cout << std::endl;
        std::cout << data << " remove failed" << std::endl;
        return false;
    }

    TreeNode *left = curNode->getLeft();
    TreeNode *right = curNode->getRight();
    if (curNode->getData() == data) { //현재 노드가 삭제노드일 경우

        if (preNode == NULL) { // curnode == root node

            if (left == NULL && right == NULL) { // none subTree
                this->rootnode = NULL;
            } else if (left == NULL &&
                       right != NULL) { // exist only right subTree
                this->rootnode = right;
            } else if (left != NULL &&
                       right == NULL) { // exist only left subTree
                this->rootnode = left;
            }
        } else { // none root node

            if (left == NULL && right == NULL) {
                if (preNode->getLeft() == curNode)
                    preNode->setLeft(NULL);
                else
                    preNode->setRight(NULL);
            } else if (left == NULL && right != NULL) {
                if (preNode->getLeft() == curNode)
                    preNode->setLeft(right);
                else
                    preNode->setRight(right);
            } else if (left != NULL && right == NULL) {
                if (preNode->getLeft() == curNode)
                    preNode->setLeft(left);
                else
                    preNode->setRight(left);
            }
        }

    } else { //현재노드가 삭제하려는 노드가 아닌 경우.
        if (curNode->getData() > data)          // data is smaller than now
            return remove(curNode, left, data); // go left subTree
        else
            return remove(curNode, right, data);
    }
    TreeNode *Tree::find_max_node(TreeNode * preNode, TreeNode * curNode) {}
