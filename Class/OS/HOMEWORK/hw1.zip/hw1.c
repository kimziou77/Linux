#include "hw1.h"

void Init(){

}

void InsertObjectToTail(Object* pObj, int ObjNum){

}

void InsertObjectToHead(Object* pObj, int objNum){

}

Object* GetObjectByNum(int objnum){    

}

Object* GetObjectFromObjFreeList(){

}

BOOL DeleteObject(Object* pObj){

}

void InsertObjectIntoObjFreeList(Object* pObj){

}

