#include "hw1.h"

void main(){

}
